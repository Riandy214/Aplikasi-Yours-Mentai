mediumZoom( '.zoom', {
	margin: 50
})