<?php 
include 'koneksi.php' ;
?>

<!doctype html>
<html lang="en">

  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css" integrity="sha384-9aIt2nRpC12Uk9gS9baDl411NQApFmC26EwAOH8WgZl5MYYxFfc+NcPb1dKGj7Sk" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="index.css">
    <link rel="stylesheet" type="text/css" href="fontawesome/css/all.min.css">
    <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.3/css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.21/css/dataTables.bootstrap4.min.css">

    <title>Yours Mentai</title>
  </head>

<body>


  <!-- Navbar -->
  <nav class="navbar navbar-expand-lg  bg-light">
    <div class="container">
      <a class="navbar-brand text-info"><strong>Yours Mentai</strong> Admin</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav"
        aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>

      <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item">
            <a class="nav-link" href="daftar_menu.php">List Menu</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="pesanan.php">Delivery Order</a>
          </li>
          <li>
            <a class="nav-link mr-4" href="pesanan_di_tempat.php">COD Order</a>
          </li>
          <li class="nav-item">
            <a class="btn btn-outline-info mr-3" href="admin.php">Beranda</a>
          </li>
          <li class="nav-item">
            <a class="btn btn-danger" href="logout.php">Keluar</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <!-- Akhir Navbar -->

  <!-- Jumbotron -->
  <div class="jumbotron jumbotron-fluid text-center">
    <div class="container">
    </div>
  </div>
  <!-- Akhir Jumbotron -->

<!-- Main content -->
  <div class="row">
    <div class="col-md-12">

      <!-- Form Laporan -->
      <div class="container">
        <div class="judul mt-5">

        <!-- form start -->
        <h3 class="text-center text-info font-weight-bold">Data Laporan pelanggan</h3>
      </div>
      <table class="table" id="example">
        <form role="form" class="form-horizontal" method="GET" action="cetak.php" target="_blank">
          <div class="box-body">

            <div class="form-group">
              <label>Tanggal</label>
              <div>
                <input type="date" class="form-control" data-date-format="dd-mm-yyyy" name="tgl_awal" autocomplete="off" required>
              </div>
              <label>s.d.</label>
              <div>
                <input type="date" class="form-control" data-date-format="dd-mm-yyyy" name="tgl_akhir" autocomplete="off" required>
            </div>
          </div>
          
          <div class="box-footer">
            <div class="form-group">
              <div class="col-sm-offset-1 col-sm-11">
                <button type="submit" class="btn btn-primary btn-social btn-submit">
                  <i class="fa fa-print"></i> Cetak
                </button>
              </div>
            </div>
          </div>
        </form>
      </table>
      </div><!-- /.box -->
    </div><!--/.col -->
  </div>   <!-- /.row -->
</body>
</html>
<?php ?>