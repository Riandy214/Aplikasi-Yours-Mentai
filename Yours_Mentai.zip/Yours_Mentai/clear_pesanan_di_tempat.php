<?php 

include('koneksi.php');

$id = $_GET['id'];

$hapus= mysqli_query($koneksi, "DELETE FROM pemesanan_di_tempat WHERE id_pemesanan='$id'");

if($hapus)
	header('location: pesanan_di_tempat.php');
else
	echo "Hapus data gagal";

 ?>